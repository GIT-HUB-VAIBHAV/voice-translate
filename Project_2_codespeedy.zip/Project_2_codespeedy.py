#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import speech_recognition as sr
from translate import Translator
import tkinter as tk
from tkinter import ttk

def translate_text():
    target_language = target_language_var.get()
    r = sr.Recognizer()

    with sr.Microphone() as source:
        status_label.config(text="Listening...", foreground="blue")

        try:
            r.adjust_for_ambient_noise(source)
            audio = r.listen(source, timeout=10)

            status_label.config(text="Audio captured. Translating...", foreground="green")

            text = r.recognize_google(audio, language='en-US')

            if text:
                translator = Translator(to_lang=target_language)
                translated_text = translator.translate(text)
                result_label.config(
                    text=f"Original text: {text}\nTranslated text ({target_language}): {translated_text}",
                    foreground="black")
                status_label.config(text="Translation complete", foreground="green")
            else:
                result_label.config(text="No speech detected or recognized.", foreground="red")
                status_label.config(text="", foreground="black")

        except sr.WaitTimeoutError:
            result_label.config(text="No speech detected within the timeout.", foreground="red")
            status_label.config(text="", foreground="black")
        except sr.UnknownValueError:
            result_label.config(text="Unable to recognize speech.", foreground="red")
            status_label.config(text="", foreground="black")
        except Exception as e:
            result_label.config(text=f"An error occurred: {str(e)}", foreground="red")
            status_label.config(text="", foreground="black")

# Create the main window
root = tk.Tk()
root.title("Voice Translator")
root.geometry("400x300")

# Create and configure GUI elements
title_label = ttk.Label(root, text="Voice Translator", font=("Helvetica", 18))
title_label.pack(pady=10)

language_label = ttk.Label(root, text="Enter target language (e.g., 'fr' for French):")
language_label.pack(pady=5)

target_language_var = tk.StringVar()
target_language_entry = ttk.Entry(root, textvariable=target_language_var)
target_language_entry.pack(pady=5)

translate_button = ttk.Button(root, text="Translate", command=translate_text)
translate_button.pack(pady=10)

result_label = ttk.Label(root, text="", wraplength=380, font=("Arial", 12))
result_label.pack()

status_label = ttk.Label(root, text="", font=("Helvetica", 12))
status_label.pack(pady=5)

# Start the GUI event loop
root.mainloop()


# In[ ]:





# In[ ]:




